# Microservice
consul agent -server -bootstrap-expect=1 -data-dir=consul-data2 -ui -bind= your ip address
